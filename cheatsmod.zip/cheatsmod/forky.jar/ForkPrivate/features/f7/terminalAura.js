//import { data, Minecraft } from "../../settings/settings"
//let clickedTerminals = []

function terminalAura(terminals) {
    //if (Client.currentGui.get() instanceof net.minecraft.client.gui.inventory.GuiChest) return
    //terminals.forEach((terminal) => {
    //    if (clickedTerminals.toString().includes(terminal.getEntity().func_145782_y())) return
    //    if (Player.getPlayer().func_70032_d(terminal.getEntity()) < data.features["Dungeons"]["Legit Aura"]["Reach"]) {
    //        Minecraft.field_71442_b.func_78768_b(Player.getPlayer(), terminal.getEntity())
    //        clickedTerminals.push(terminal.getEntity().func_145782_y())
    //    }
    //})
}

export { terminalAura }