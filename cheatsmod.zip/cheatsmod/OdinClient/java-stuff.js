export const Executors = Java.type("java.util.concurrent.Executors")
export const File = Java.type("java.io.File")
export const ResourceLocation = Java.type("net.minecraft.util.ResourceLocation")
export const ItemSkull = Java.type("net.minecraft.item.ItemSkull");