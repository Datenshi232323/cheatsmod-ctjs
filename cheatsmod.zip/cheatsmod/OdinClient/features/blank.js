import { data } from "../stuff/guidk"
import { modMessage} from "../utils";

//module name